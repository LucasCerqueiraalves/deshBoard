<?
    require_once 'classes/usuario.php';
    $u = new Usuario;
?>
 
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="assets/css/styleCadastrar.css"/>
    <link rel="stylesheet" type="text/css" href="assets/css/styleLogin.css"/>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
    href="https://fonts.googleapis.com/css2?family=Lora:wght@400;600&family=Poppins:wght@300;400;600;700&display=swap"
    rel="stylesheet"/>
    <title>Barbearia Hermanos</title>
</head>
<body>
    <div class="containerCadastro">
        <div class="bannerCadastro">
            <img src="assets/image/bannerCadastrar.jpg" alt="banner"/>
        </div>

        <div class="formularioCadastro">
            <p>Cadastrar</p>
            <form method="post" >
                <input type="text" name="nome" placeholder="Digite seu nome" autocomplete="off" maxlength="30" autofocus required/><br/>
                <input type="text" name="sobrenome" placeholder="Digite seu sobrenome" autocomplete="off" maxlength="40" required/><br/>
                <input type="email" name="email" placeholder="Digite seu email" autocomplete="off" maxlength="50" required/><br/>
                <input type="password" name="senha" placeholder="Digite sua senha" autocomplete="off" maxlength="15" required/>
                <div class="botao">
                    <a href="login.html" class="voltar">voltar</a>
                    <a href="login.html" >Cadastrar</a>
                </div>
            </form>
            
        </div>
    </div>



<?
    //verificar se a pessoa cliclou no botão 

    isset($_POST['nome']) {
        $nome = addslashes( $_POST['nome']);

        $sobrenome = addslashes( $_POST['sobrenome']);

        $email = addslashes( $_POST['email']);

        $senha = addslashes( $_POST['senha']);

        //verificar se não esta vazio o campo

        if(!empty($nome) && !empty($sobrenome) && !empty($email) && !empty($senha)){
            
        }
        else{
            echo "Preencha todos os campos!";
        }
    }



?>
</body>
</html>